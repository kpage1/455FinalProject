from flask import Flask, flash, redirect, render_template, request, session, abort
# from config import Config

app = Flask(__name__)
# app.config.from_object(Config)


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/players")
def player():
    return render_template("players.html")

@app.route("/teams")
def team():
    return render_template("teams.html")

@app.route("/gameData")
def data():
    return render_template("gameData.html")

@app.route("/shopping")
def shop():
    return render_template("shopping.html")
@app.route("/login", methods=["POST","GET"])
def login():
    if request.method == "POST":
        session.permanent = True
        user = request.form["nm"]
        session["user"] = user
        return redirect(url_for("user", usr=user))
    else:
        if "user" in session:
            return redirect(url_for("user"))
        return render_template("login.html")

@app.route("/user")
def user():
    if "user" in session:
        user = session["user"]
        # return f"<h1>{user}</h1>"
    else:
        return redirect(url_for("login"))

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))


def get_db_connection():
    import sqlite3
    conn = sqlite3.connect('database/nba.db')
    conn.row_factory = sqlite3.Row

    return conn.cursor()


if __name__ == "__main__":
    # app.run(host='0.0.0.0', port=80)
    app.run(debug=False)